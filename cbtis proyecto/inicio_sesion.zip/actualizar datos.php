<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos del Alumno</title>
    <link rel="icon" type="image/png" href="cbtis 258.jfif">
    <link rel="stylesheet" href="actualizar.css">
</head>

<body background="cobrafondo.png">

<div class="contenedor">
    <h1>DATOS PARA ACTUALIZAR DEL/LA ALUMN@</h1>
    <div class="linea"></div>
    <div class="dato nombre">
        <label>NOMBRE DEL/LA ALUMN@</label>
        <input type="text">
    </div>
    <div class="dato especialidad">
        <label>ESPECIALIDAD</label>
        <input type="text">
    </div>
    <div class="dato semestre">
        <label>SEMESTRE Y GRUPO</label>
        <input type="text">
    </div>
    <div class="dato semestre">
        <label>TURNO</label>
        <input type="text">
    </div>
    <div class="credenciales">
        <p>Credencial(es) de<br>persona autorizadaS</p>
        <div class="fotos">
            <div class="foto"></div>
            <div class="foto"></div>
            <div class="foto"></div>
            <div class="foto"></div>
        </div>
    </div>
    <div class="botones">
        <button>
            <a href="###" style="text-decoration: none; color: rgb(151, 0, 0);">ACTUALIZAR</a>
        </button>
        <button>
            <a href="Inicio.php" style="text-decoration: none; color: white;">VOLVER AL INICIO</a>
        </button>
    </div>
</div>

</body>
</html>